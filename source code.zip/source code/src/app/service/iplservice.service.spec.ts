import { TestBed } from '@angular/core/testing';

import { IPLServiceService } from './iplservice.service';

describe('IPLServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IPLServiceService = TestBed.get(IPLServiceService);
    expect(service).toBeTruthy();
  });
});
