import { Component, OnInit } from '@angular/core';
import { IPLService } from './service/iplservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'DreamTeam';
  dataURL = '/assets/json/player-profile.json';
  playerStats: any;
  totalPlayers: number;
  selectedPlayers: number = 0;
  totalSelectedStrength: number = 0.00;
  totalSelectedValue: number = 0;
  availableAmount: number = 100000000;
  isDraggable: boolean = true;
  hasLimitReached: boolean = false;
  userMsg: string ="Thanks for selecting the team. You have a strong team. All the best!!"; 

  constructor(private srv: IPLService){ }

  ngOnInit(): void{
    this.srv.getPlayerStats(this.dataURL).subscribe(data => {
      this.playerStats = data;
      this.totalPlayers = this.playerStats.length;
    })
  }

  /**
   * Method to identify the selected players and calculate team strength.
   */
  getSelectedPlayers(): void{
    let _myTeam = document.querySelectorAll('.selected-section app-player-stats');
    let selected_array = [];
    for(let i=0;i<_myTeam.length;i++){
      let _currentPlayer = _myTeam[i].firstElementChild.getAttribute('id')
      selected_array.push(_currentPlayer.replace('player-id-',''));
    }

    this.totalSelectedStrength = this.getPlayerStrength(selected_array) | 0.00;
  } 

  /**
   * Method to filter selected players stats.
   * @param selected_array - Array of selected player IDs
   * @returns team's strength
   */
  getPlayerStrength(selected_array): any{
    this.totalSelectedValue = 0;
    let _total =  selected_array.reduce((prev,player)=>{
      let _thisPlayerStats = this.playerStats.find((playerData)=>{
        return playerData['id'] == player;
      });
      prev += this.calculateStrength(_thisPlayerStats);
      this.totalSelectedValue += _thisPlayerStats['value'];
      return prev;
    },0);

    return _total/(selected_array.length * 3);
  }

  /**
   * Method to sum up individual stats 
   * @param _thisPlayerStats 
   */
  calculateStrength(_thisPlayerStats): number{
    return (100 - _thisPlayerStats['batting_rank']) + (100 - _thisPlayerStats['bowling_rank']) + (100 - _thisPlayerStats['all_round_rank']);
  }

 // Functions to drag and drop custom elements - START
  allowDrop(ev) {
    ev.preventDefault();
  }

  drag(ev) {
    ev.dataTransfer.setData("selectedPlayer", ev.target.id);
  }

  // Function to drag and drop custom elements - END
  
  drop(ev) {
    
     let target = ev.target;
    
        let data = ev.dataTransfer.getData("selectedPlayer");
        let closest = target.closest('.items-container');
        (null != closest) ? (closest.parentNode.insertBefore(document.getElementById(data), closest)) :(target.appendChild(document.getElementById(data)))
    
        //To fetch selected players and capture the length
        let _myTeam = document.querySelectorAll('.selected-section app-player-stats');
        this.selectedPlayers = _myTeam.length;

        let _left = document.querySelector('.left-container');
        if(this.selectedPlayers > 14) {
          _left.classList.add('stop-propagation') ;
          this.hasLimitReached = true;
        }

        this.getSelectedPlayers();
  }
}


